# back-componentization-example
基于express和handlebars实现后端组件化示例

原文地址：[利用handlebars实现后端组件化](http://yalishizhude.github.io/2016/04/26/back-componentization/)
