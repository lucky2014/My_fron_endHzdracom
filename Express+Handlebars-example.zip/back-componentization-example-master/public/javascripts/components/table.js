(function(){
  'use strict';
  $('#table').before('<h1>This is table</h1>');
}());
