(function(){
  $('#navigator').before("<h5>I'm navigator</h5>");
}());
